(function(){var loadHandler=window['sl_{ADA6B015-EAEB-484E-B768-6D593B49DFC4}'];loadHandler&&loadHandler(94, '<div id="spr0_f3cec2e5"><div id="spr1_f3cec2e5" class="kern slide"><img id="img1_f3cec2e5" src="data/img1.png" width="960px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_f3cec2e5" class="kern slide"><div id="spr3_f3cec2e5" style="left:62.743px;top:23.607px;"><div style="width:0px;"><span id="txt0_f3cec2e5" data-width="460.800781" style="left:183.96px;top:26.652px;">Intent APIs - Northbound</span></div></div><div id="spr4_f3cec2e5" style="left:30px;top:131px;"><img id="img0_f3cec2e5" src="data/img494.png" width="858" height="321" alt="REST API that exposes specific capabilities of DNAC\
Discovers and controls the networking using HTTPS verbs (GET, POST, PUT and DELETE)with JSON structures\
Grouped into “Domains” and “Subdomains”\
Authentication Domain – Authentication  Subdomain\
Know you Network – Sites Topology, Devices, Clients,  Users,  Issues\
Site Management – Site Design, Network Settings, Software Image Management, Device Onboarding, Configuration Templates \
Connectivity – (Beta) Fabric Wired, Non-Fabric Wireless  \
Operational Tasks – Command Runner, Network Discovery, Path Trace, File, Task, Tag\
Policy – Application Policy\
Event Management – Event Management"/></div></div></div>', '{"s":[]}');})();