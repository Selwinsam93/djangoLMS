(function(){var loadHandler=window['sl_{ADA6B015-EAEB-484E-B768-6D593B49DFC4}'];loadHandler&&loadHandler(1, '<div id="spr0_f3cda705"><div id="spr1_f3cda705" class="kern slide"><img id="img2_f3cda705" src="data/img1.png" width="960px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_f3cda705" class="kern slide"><div id="spr3_f3cda705" style="left:74px;top:69px;"><img id="img0_f3cda705" src="data/img2.png" width="144" height="38" alt="Agenda	"/></div><div id="spr4_f3cda705" style="left:75px;top:130px;"><img id="img1_f3cda705" src="data/img3.png" width="702" height="332" alt="Intent based Network Architecture\
Understanding Cisco DNA Center \
Cisco DNA Center Platform Overview\
Cisco DNA Center - Application Programming Interfaces\
DNA Center Assurance and Configuration compliance check\
Network Device Analytics, Insights and Monitoring\
Events and Notifications\
\
"/></div></div></div>', '{"s":[]}');})();