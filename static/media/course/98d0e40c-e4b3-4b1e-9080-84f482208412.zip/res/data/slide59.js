(function(){var loadHandler=window['sl_{ADA6B015-EAEB-484E-B768-6D593B49DFC4}'];loadHandler&&loadHandler(58, '<div id="spr0_f3ce6b40"><div id="spr1_f3ce6b40" class="kern slide"><img id="img3_f3ce6b40" src="data/img1.png" width="960px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_f3ce6b40" class="kern slide"><div id="spr3_f3ce6b40" style="left:66px;top:28.75px;"><div style="width:0px;"><span id="txt0_f3ce6b40" data-width="505.898438" style="left:162.105px;top:26.652px;">Cisco DNA Center – Benefits</span></div></div><div id="spr4_f3ce6b40" style="left:75px;top:164px;"><img id="img0_f3ce6b40" src="data/img302.png" width="249" height="306" alt="Secure Access \
Translate business intent into zerotrust policies\
Dynamic segmentation of endpoints based on usage behaviour"/></div><div id="spr5_f3ce6b40" style="left:377px;top:164px;"><img id="img1_f3ce6b40" src="data/img303.png" width="244" height="322" alt="Simplify Management\
Policy driven provisioning\
Increased network uptime\
Reduced Time spent managing network operations"/></div><div id="spr6_f3ce6b40" style="left:694px;top:160px;"><img id="img2_f3ce6b40" src="data/img304.png" width="258" height="307" alt="Network Integrity with AI/ML network insights Analytics\
Intelligent network Optimizations\
Extended domains with integrated services"/></div></div></div>', '{"s":[]}');})();