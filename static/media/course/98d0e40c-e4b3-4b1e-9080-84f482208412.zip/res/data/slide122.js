(function(){var loadHandler=window['sl_{ADA6B015-EAEB-484E-B768-6D593B49DFC4}'];loadHandler&&loadHandler(121, '<div id="spr0_f3cf1ccd"><div id="spr1_f3cf1ccd" class="kern slide"><img id="img4_f3cf1ccd" src="data/img1.png" width="960px" height="540px" alt="" style="left:0px;top:0px;"/></div><div id="spr2_f3cf1ccd" class="kern slide"><div id="spr3_f3cf1ccd" style="left:41.917px;top:17.127px;"><div style="width:0px;"><span id="txt0_f3cf1ccd" data-width="709.277344" style="left:86.253px;top:-8.719px;">Configure Cisco DNA Center Webhooks</span></div><div style="width:0px;"><span id="txt1_f3cf1ccd" data-width="218.652344" style="left:328.833px;top:34.481px;">(continued)</span></div></div><div id="spr4_f3cf1ccd" style="left:523px;top:113px;"><img id="img0_f3cf1ccd" src="data/img590.png" width="444" height="373" alt="Name your subscription\
Subscription Type – REST\
Create a new endpoint\
Description of the new endpoint\
URL - https://your_app_url/webhook\
Trust Certificate – yes\
HTTP Method – POST\
Authentication – Basic\
Headers – Authorization + Basic YWRtaW4…\
Subscribe\
"/></div><div id="spr5_f3cf1ccd" style="left:24.934px;top:113.46px;"><div id="spr6_f3cf1ccd" style="left:-0.934px;top:-2.46px;"><img id="img1_f3cf1ccd" src="data/img591.png" width="545" height="400" alt=""/></div><div id="spr7_f3cf1ccd" style="left:60.357px;top:141.899px;"><img id="img2_f3cf1ccd" src="data/img592.jpg" width="9" height="10" alt="" style="left:0.022px;top:-0.167px;"/></div><div id="spr8_f3cf1ccd" style="left:138.8px;top:141.899px;"><img id="img3_f3cf1ccd" src="data/img593.jpg" width="9" height="10" alt="" style="left:0.167px;top:-0.167px;"/></div></div></div></div>', '{"s":[]}');})();